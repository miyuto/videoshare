function cmb_after_upload_file_callback(model, cmb_frame){
    var val = jQuery('#tm_video_file-cmb-field-0').val();
    jQuery('#tm_video_file-cmb-field-0').val(val + (val != '' ? '\r\n' : '') + model.attributes.url) ;
    
    jQuery('#videopro_video_file .field-item').each(function(){
       if(jQuery(this).find('.cmb-file-holder .cmb-file-name').length > 0){
           jQuery(this).remove();
       }
    });
}