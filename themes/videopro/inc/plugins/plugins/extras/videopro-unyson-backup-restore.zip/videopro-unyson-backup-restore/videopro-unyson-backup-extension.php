<?php
/**
 *  Plugin Name: VideoPro - Unyson Sample Data
 *  Description: Import demo data for VideoPro
 *  Author: CactusThemes
 *  Author URI: https://themeforest.net/user/cactusthemes
 *  Version: 1.0.5
 *  Text Domain: videopro
 * @since 1.0.0
 */

if (!defined('videopro_UNYSON_BACKUP_DIR')) {
    define('videopro_UNYSON_BACKUP_DIR', plugin_dir_path(__FILE__));
}
if (!defined('videopro_UNYSON_BACKUP_URI')) {
    define('videopro_UNYSON_BACKUP_URI', plugin_dir_url(__FILE__));
}

class videopro_UNYSON_BACKUP
{
    public function __construct()
    {
        global $pagenow;

        if (!defined('FW')) :
            add_filter('fw_framework_directory_uri', array($this, '_filter_fw_framework_plugin_directory_uri'));
            require videopro_UNYSON_BACKUP_DIR . '/framework/bootstrap.php';
        endif;
        add_action('videopro_before_demo_content_install', array($this, 'notification_before_html'));
        add_action('videopro_after_demo_content_install', array($this, 'notification_after_html'));
        add_action('admin_enqueue_scripts', array($this, 'videopro_unyson_backup_restore_script'));
        add_action('admin_init', array($this, 'videopro_activation_sampledata_redirect'), 10);

        //disable menu, session of Unyson Framework
        add_filter('fw_backend_enable_custom_extensions_menu', array($this, '_filter_fw_backend_enable_custom_extensions_menu'));
        add_filter('fw_use_sessions', array($this, '_filter_fw_use_sessions'));
        add_filter('fw_loader_image', array($this, 'videopro_fw_loader_image'));
        add_filter('fw:ext:backups-demo:demos', array($this, '_filter_theme_fw_ext_backups_demos'));

        register_activation_hook(__FILE__, array($this, 'videopro_active'));
        register_activation_hook(__FILE__, array($this, 'videopro_activation_sampledata'));
    }

    function videopro_active()
    {
        $extension = get_option('fw_active_extensions', null);
        $extension['backups'] = array();
        $extension['backups-demo'] = array();
        update_option('fw_active_extensions', $extension);
    }

    function _filter_fw_framework_plugin_directory_uri()
    {
        return videopro_UNYSON_BACKUP_URI . '/framework';
    }

    function _filter_fw_backend_enable_custom_extensions_menu ($is_enable_menu)
    {
        return $is_enable_menu = false;
    }

    function _filter_fw_use_sessions ($is_use_sessions)
    {
        return $is_use_sessions = false;
    }

    function videopro_unyson_backup_restore_script()
    {
        wp_enqueue_style('videopro-backup-restore', videopro_UNYSON_BACKUP_URI . 'assets/css/admin.css');
    }

    function notification_before_html()
    {
        if (!current_user_can('manage_options')) {
            global $current_user;
            $msg = sprintf(esc_html__("I'm sorry, %s I'm afraid I can't do that.", 'videopro'), $current_user->display_name);
            echo '<div class="wrap">' . $msg . '</div>';
            return false;
        }
        ?>
        <div class="videopro-demo-container">
        <div id="primary">
        <div class="import-admin-title">
            <h2>
                <span class="dashicons dashicons-upload"></span>
                <span class="text"><?php esc_html_e('Import Sample Data', 'videopro'); ?></span>
            </h2>
        </div>
        <div class="videopro-admin-notice">
            <ul>
                <li><?php esc_html_e('Make sure you only install sample data in a freshly installed website', 'videopro'); ?>
                </li>
                <li><?php esc_html_e('It is recommended to install all required and recommended plugins before installing sample data, including "Widget Logic" plugin', 'videopro'); ?></li>
                <li><?php esc_html_e('For VideoPro - Cooking, you will need to use VideoPro-Child  child theme', 'videopro'); ?></li>
                <li><?php esc_html_e('For VideoPro - Poster, you will need to use VideoPro-Poster child theme', 'videopro'); ?></li>
            </ul>
        </div>
        <?php
    }

    function notification_after_html()
    { ?>
        </div>
        <div id="secondary">
            <?php do_action('videopro_unyson_backup_sidebar') ?>
        </div>
        </div>
    <?php }

    function videopro_activation_sampledata()
    {
        add_option('videopro_activation_sampledata_redirect', true);
    }

    function videopro_fw_loader_image($image)
    {
        $image = videopro_UNYSON_BACKUP_URI . 'assets/images/logo.png';
        return $image;
    }

    function videopro_activation_sampledata_redirect()
    {
        if (get_option('videopro_activation_sampledata_redirect', false)) {
            delete_option('videopro_activation_sampledata_redirect');
            if (!isset($_GET['activate-multi'])) {
                wp_redirect(admin_url('tools.php?page=fw-backups-demo-content'));
            }
        }
    }

    /**
     * @param FW_Ext_Backups_Demo[] $demos
     * @return FW_Ext_Backups_Demo[]
     * using for download demo from remote server
     */
    function _filter_theme_fw_ext_backups_demos($demos)
    {
        $demos_array = array(
            'videopro-cooking-sample-data' => array(
                'title' => esc_html__('VideoPro - Cooking', 'videopro'),
                'screenshot' => 'http://videopro.cactusthemes.com/data/videopro-cooking.jpg',
                'preview_link' => 'http://videopro.cactusthemes.com/cooking',
            ),
            'videopro-poster-sample-data' => array(
                'title' => esc_html__('VideoPro - Poster', 'videopro'),
                'screenshot' => 'http://videopro.cactusthemes.com/data/videopro-poster.jpg',
                'preview_link' => 'http://videopro.cactusthemes.com/poster',
            ),
            'videopro-v1-sample-data' => array(
                'title' => esc_html__('VideoPro - Demo 1 (General)', 'videopro'),
                'screenshot' => 'http://videopro.cactusthemes.com/data/videopro-v1.jpg',
                'preview_link' => 'http://videopro.cactusthemes.com/v1',
            ),
            'videopro-v2-sample-data' => array(
                'title' => esc_html__('VideoPro - Demo 2 (Membership)', 'videopro'),
                'screenshot' => 'http://videopro.cactusthemes.com/data/videopro-v2.jpg',
                'preview_link' => 'http://videopro.cactusthemes.com/v2',
            ),
        );

        $download_url = 'http://videopro.cactusthemes.com/data/';

        foreach ($demos_array as $id => $data) {
            $demo = new FW_Ext_Backups_Demo($id, 'piecemeal', array(
                'url' => $download_url,
                'file_id' => $id,
            ));
            $demo->set_title($data['title']);
            $demo->set_screenshot($data['screenshot']);
            $demo->set_preview_link($data['preview_link']);

            $demos[$demo->get_id()] = $demo;

            unset($demo);
        }
        return $demos;
    }
}

$GLOBALS['videopro_unyson_backup'] = new videopro_UNYSON_BACKUP();
